"""Phase 0 - read your hardware and measure how precise the timer is.

Run:  python task0_cal.py
"""
import statistics
import time

import labutil as L
from harness import emit_verify_tag

N_READS = 2_000_000


def main():
    hw = L.detect_hardware()
    L.save_json("hardware", hw)          # later phases read P_phys etc. from here

    clock = time.perf_counter_ns
    for _ in range(10_000):              # warm-up
        clock()

    # 1) average cost of one clock read over 2 million reads
    t0 = clock()
    for _ in range(N_READS):
        clock()
    t1 = clock()
    avg_ns = (t1 - t0) / N_READS

    # 2) noise floor: the smallest step the timer can show between two reads
    steps = []
    prev = clock()
    for _ in range(200_000):
        now = clock()
        if now > prev:
            steps.append(now - prev)
        prev = now
    floor_ns = min(steps)
    median_step = statistics.median(steps)

    tag = emit_verify_tag("PHASE0", L.student_id(), avg_ns, float(floor_ns))
    L.save_json("phase0", {"avg_call_ns": avg_ns, "floor_ns": floor_ns, "tag": tag})

    rows = [
        ["CPU Model String", hw["cpu_model"], "L1 Data Cache (per core)", L.fmt_size(hw["l1d_bytes"])],
        ["Physical Cores (P_phys)", hw["p_phys"], "L2 Cache Size", L.fmt_size(hw["l2_bytes"])],
        ["Logical Threads (P_log)", hw["p_log"], "L3 Cache Size (Shared)", L.fmt_size(hw["l3_bytes"])],
        ["Cache Line Size (L_bytes)", f"{hw['line_bytes']} B", "Python Version & OS", hw["python_os"]],
    ]
    text = "## 1. Hardware Baseline (Phase 0)\n\n"
    text += L.md_table(["Hardware Parameter", "Measured Value", "Hardware Parameter", "Measured Value"], rows)
    if hw["p_perf_cores"]:
        text += f"\n\nHybrid CPU: {hw['p_perf_cores']} performance cores + " \
                f"{hw['p_phys'] - hw['p_perf_cores']} efficiency cores."
    text += "\n\n### Raw OS output\n\n```text\n" + (hw["raw_os_output"] or "(none)") + "\n```\n"
    text += "\n### Timer calibration (`time.perf_counter_ns`)\n\n"
    text += L.md_table(["Measurement", "Value"], [
        ["Clock reads", f"{N_READS:,}"],
        ["Average cost of one read", f"{avg_ns:.2f} ns"],
        ["Smallest visible step (noise floor)", f"{floor_ns} ns"],
        ["Median step between back-to-back reads", f"{median_step:.0f} ns"],
    ])
    text += f"\n\n```text\n{tag}\n```\n"
    L.write_section("phase0", text)

    missing = [k for k in ("l1d_bytes", "l2_bytes", "line_bytes") if not hw[k]]
    if missing:
        print("\nNOTE: could not detect", ", ".join(missing),
              "- type the values into lab_config.py and run this script again.")


if __name__ == "__main__":
    main()
