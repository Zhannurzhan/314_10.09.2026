"""Phase 1 - false sharing: processes write to neighbouring 8-byte slots of one shared buffer.

Run:  python task1_falsesharing.py
"""
import ctypes
from multiprocessing import shared_memory

import labutil as L
from harness import emit_verify_tag, run_benchmark

M_TOTAL = 2_400_000 if L.QUICK else 24_000_000   # total steps, split across p workers
STRIDES = [1, 2, 4, 8, 16, 32]                    # distance between slots, in 8-byte words


def fs_worker(shm_name: str, slot_idx: int, iters: int, n_slots: int) -> None:
    shm = L.attach_shm(shm_name)
    arr = (ctypes.c_uint64 * n_slots).from_buffer(shm.buf)
    acc = arr[slot_idx]
    mask = 0xFFFFFFFFFFFFFFFF
    mult = 6364136223846793005
    for i in range(iters):
        acc = (acc * mult + (i | 1)) & mask
        arr[slot_idx] = acc  # store into the shared cache line on EVERY step
    del arr  # release buffer export before closing SharedMemory
    shm.close()


def fs_task(shm_name, slot_idx, iters, n_slots):
    L.sync()          # each task in its own process, all start at the same moment
    fs_worker(shm_name, slot_idx, iters, n_slots)


def main():
    hw = L.load_json("hardware")
    p_phys, p_log = hw["p_phys"], hw["p_log"]
    procs = sorted({2 ** k for k in range(20) if 2 ** k <= p_log} | {p_phys, p_log})

    n_slots = max(512, ((p_log - 1) * max(STRIDES) // 512 + 1) * 512)
    size = n_slots * 8
    shm = shared_memory.SharedMemory(create=True, size=size)
    res = {}
    try:
        for p in procs:
            iters = M_TOTAL // p
            strides = STRIDES if p == p_phys else [1, 16]
            with L.make_pool(p) as pool:
                for stride in strides:
                    shm.buf[:size] = bytes(size)
                    args = [(shm.name, t * stride, iters, n_slots) for t in range(p)]
                    st = run_benchmark(lambda: pool.starmap(fs_task, args, chunksize=1),
                                       warmup_runs=2, timed_runs=7)
                    res[(p, stride)] = (st, p * iters)
                    print(f"  p={p:<3} stride={stride:<3} median={st.median_ms:9.1f} ms", flush=True)
    finally:
        shm.close()
        shm.unlink()

    # ---------------- Table 1A: stride sweep at p = P_phys
    rows = []
    base = res[(p_phys, 32)][0].median_ms
    for s in STRIDES:
        st, total = res[(p_phys, s)]
        rows.append([s, s * 8, f"{st.median_ms:.1f}", f"{st.iqr_ms:.1f}",
                     f"{total / (st.median_ms / 1000) / 1e6:.2f}", f"{st.median_ms / base:.2f}x"])
    meds = [res[(p_phys, s)][0].median_ms for s in STRIDES]
    drops = [(meds[i] / meds[i + 1], i) for i in range(len(STRIDES) - 1)]
    best_ratio, bi = max(drops)
    settled = next(s for s, m in zip(STRIDES, meds) if m <= 1.10 * base)

    text = f"## 2. Phase 1: False Sharing\n\nM = {M_TOTAL:,} total steps, p = P_phys = {p_phys}.\n\n"
    text += "### Table 1A: Stride sensitivity (p = P_phys)\n\n"
    text += L.md_table(["Stride (words)", "Separation (bytes)", "Median (ms)", "IQR (ms)",
                        "Throughput (Mops/s)", "Time vs stride 32"], rows)
    text += (f"\n\n- Biggest drop: from {STRIDES[bi] * 8} B to {STRIDES[bi + 1] * 8} B "
             f"separation ({best_ratio:.2f}x faster).\n"
             f"- Time reaches the no-sharing level (within 10% of stride 32) at "
             f"**{settled * 8} bytes** -> measured coherence line width.\n"
             f"- OS-reported cache line: {hw['line_bytes']} B.\n")

    # ---------------- Table 1B: Karp-Flatt
    kf = {}
    for stride in (1, 16):
        t1 = res[(1, stride)][0].median_ms
        rows = []
        kf[stride] = []
        for p in procs:
            tp = res[(p, stride)][0].median_ms
            sp = t1 / tp
            ep = sp / p
            if p >= 2:
                e = (1 / sp - 1 / p) / (1 - 1 / p)
                kf[stride].append((p, e))
                e_txt = f"{e:.4f}"
            else:
                e_txt = "-"
            rows.append([p, f"{tp:.1f}", f"{sp:.3f}", f"{ep:.3f}", e_txt])
        text += f"\n### Table 1B: Karp-Flatt series, stride = {stride} ({stride * 8} B apart)\n\n"
        text += L.md_table(["p", "T_p (ms)", "S_p", "E_p", "e(p)"], rows) + "\n"

    if kf[1]:
        p_last = kf[1][-1][0]
        text += (f"\n- e(p) at p = {p_last}: stride 1 = {kf[1][-1][1]:.4f}, "
                 f"stride 16 = {kf[16][-1][1]:.4f}.\n")
    text += ("\n**Forensic explanation (edit in your own words):** with stride 1 all workers write "
             "into the same cache line. Each write forces the core to take ownership of that line "
             "(MESI), which invalidates the copy in every other core. The line keeps moving between "
             "cores, so time that should be parallel turns into waiting. Karp-Flatt counts that "
             "waiting as 'serial fraction', so e(p) rises with p. With stride 16 (128 B) each worker "
             "owns its own line, nothing is invalidated, and e(p) stays small and flat. In Python the "
             "effect is smaller than in C, because the interpreter spends ~50-100 ns per loop step.\n")

    m1 = res[(p_phys, 1)][0].median_ms
    m16 = res[(p_phys, 16)][0].median_ms
    tag = emit_verify_tag("PHASE1", L.student_id(), m1, m16)
    text += f"\n```text\n{tag}\n```\n"
    L.save_json("phase1", {"median_stride1": m1, "median_stride16": m16,
                           "line_detected": settled * 8, "tag": tag})
    L.write_section("phase1", text)


if __name__ == "__main__":
    main()
