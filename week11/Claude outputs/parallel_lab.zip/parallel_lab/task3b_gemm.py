"""Phase 3B - three parallel GEMM versions and a 10-point tile-size sweep.

Run:  python task3b_gemm.py      (run task3a_roofline.py first)
"""
import atexit
from array import array
from multiprocessing import shared_memory

import labutil as L
from harness import emit_verify_tag, run_benchmark

N = 96 if L.QUICK else 384
BS_LIST = [4, 8, 12, 16, 24, 32, 48, 64, 96, 128]
WARMUP, TIMED = 1, 3

_M = {}


def gemm_init(names, n):
    for key, name in zip("ABC", names):
        shm = L.attach_shm(name)
        _M[key + "shm"] = shm
        _M[key] = shm.buf.cast("d")       # flat 1-D array of doubles
    _M["N"] = n
    atexit.register(_cleanup)


def _cleanup():
    for key in "ABC":
        _M[key].release()
        _M[key + "shm"].close()


def gemm_naive(lo, hi):
    """Variant 1: i-j-k. Inner loop walks B down a column (stride N)."""
    A, B, C, N = _M["A"], _M["B"], _M["C"], _M["N"]
    for i in range(lo, hi):
        for j in range(N):
            dot = 0.0
            for k in range(N):
                dot += A[i * N + k] * B[k * N + j]
            C[i * N + j] = dot


def gemm_ikj(lo, hi):
    """Variant 2: i-k-j. a_ik hoisted, inner loop walks rows of B and C with stride 1."""
    A, B, C, N = _M["A"], _M["B"], _M["C"], _M["N"]
    for i in range(lo, hi):
        iN = i * N
        crow = [0.0] * N
        for k in range(N):
            aik = A[iN + k]
            kN = k * N
            for j in range(N):
                crow[j] += aik * B[kN + j]
        C[iN:iN + N] = array("d", crow)


def gemm_blocked(lo, hi, bs):
    """Variant 3: 6 loops. Tiles of bs x bs; micro-kernel order i-k-j with a_ik hoisted."""
    A, B, C, N = _M["A"], _M["B"], _M["C"], _M["N"]
    for ii in range(lo, hi, bs):
        i_end = min(ii + bs, hi)
        rows = [[0.0] * N for _ in range(ii, i_end)]          # C tile rows for this i-block
        for jj in range(0, N, bs):
            j_end = min(jj + bs, N)
            for kk in range(0, N, bs):
                k_end = min(kk + bs, N)
                for i in range(ii, i_end):                    # ---- micro-kernel
                    crow = rows[i - ii]
                    iN = i * N
                    for k in range(kk, k_end):
                        aik = A[iN + k]                       # hoisted out of the j loop
                        kN = k * N
                        for j in range(jj, j_end):
                            crow[j] += aik * B[kN + j]
        for i in range(ii, i_end):
            C[i * N:(i + 1) * N] = array("d", rows[i - ii])


def gemm_task(variant, lo, hi, bs):
    L.sync()
    if variant == 1:
        gemm_naive(lo, hi)
    elif variant == 2:
        gemm_ikj(lo, hi)
    else:
        gemm_blocked(lo, hi, bs)


def main():
    hw = L.load_json("hardware")
    roof = L.load_json("phase3a")
    p = hw["p_phys"]
    nbytes = N * N * 8
    shms = [shared_memory.SharedMemory(create=True, size=nbytes) for _ in range(3)]
    sA, sB, sC = shms
    sA.buf[:nbytes] = array("d", [((i * 7 + j * 3) % 11 - 5) / 7.0
                                  for i in range(N) for j in range(N)]).tobytes()
    sB.buf[:nbytes] = array("d", [((i * 5 + j * 2) % 13 - 6) / 9.0
                                  for i in range(N) for j in range(N)]).tobytes()

    def read_c():
        c = array("d")
        c.frombytes(bytes(sC.buf[:nbytes]))
        return c

    def run(variant, bs=0):
        sC.buf[:nbytes] = bytes(nbytes)
        args = [(variant, lo, hi, bs) for lo, hi in L.split(N, p)]
        st = run_benchmark(lambda: pool.starmap(gemm_task, args, chunksize=1), WARMUP, TIMED)
        return st, read_c()

    flops = 2 * N ** 3
    results = []
    try:
        with L.make_pool(p, gemm_init, ([s.name for s in shms], N)) as pool:
            st2, c2 = run(2)
            print(f"  V2 i-k-j      {st2.median_ms:9.1f} ms", flush=True)
            st1, c1 = run(1)
            print(f"  V1 naive      {st1.median_ms:9.1f} ms", flush=True)
            err1 = max(abs(x - y) for x, y in zip(c1, c2))
            results.append(("V1 naive i-j-k", "-", st1, err1))
            results.append(("V2 i-k-j", "-", st2, 0.0))
            for bs in BS_LIST:
                st3, c3 = run(3, bs)
                err = max(abs(x - y) for x, y in zip(c3, c2))
                results.append(("V3 blocked", bs, st3, err))
                print(f"  V3 BS={bs:<4}   {st3.median_ms:9.1f} ms  max|C3-C2|={err:.1e}", flush=True)
    finally:
        for s in shms:
            s.close()
            s.unlink()

    l1, l2 = hw.get("l1d_bytes"), hw.get("l2_bytes")
    peak, bw, ridge = roof["peak_gflops"], roof["bw_gbs"], roof["ridge"]

    def gf(st):
        return flops / (st.median_ms / 1000) / 1e9

    rows = []
    for name, bs, st, err in results:
        if bs == "-":
            fp, f1, f2 = "-", "-", "-"
        else:
            w = 3 * bs * bs * 8
            fp = f"{w / 1024:.1f} KB"
            f1 = "unknown" if not l1 else ("yes" if w <= l1 else "no")
            f2 = "unknown" if not l2 else ("yes" if w <= l2 else "no")
        rows.append([name, bs, fp, f1, f2, f"{st.median_ms:.1f}", f"{gf(st):.4f}", f"{err:.1e}"])

    v3 = [r for r in results if r[0] == "V3 blocked"]
    best_bs, best_st = max(((bs, st) for _, bs, st, _ in v3), key=lambda x: gf(x[1]))
    all_ok = all(r[3] < 1e-9 for r in v3)

    text = (f"### Part 3B: GEMM, N = {N}, {p} workers, 2N^3 = {flops:,} FLOPs\n\n"
            f"Tile footprint W_tile = 3 x BS^2 x 8 bytes. L1d per core = {L.fmt_size(l1)}, "
            f"L2 = {L.fmt_size(l2)}.\n\n")
    text += L.md_table(["Variant", "BS", "W_tile", "Fits L1d?", "Fits L2?", "Median (ms)",
                        "GFLOP/s", "max err vs V2"], rows)
    text += (f"\n\n- Numerical check (V3 vs V2, max |diff| < 1e-9): **{'PASS' if all_ok else 'FAIL'}**\n"
             f"- Best tile BS* = **{best_bs}** ({gf(best_st):.4f} GFLOP/s), "
             f"footprint {3 * best_bs ** 2 * 8 / 1024:.1f} KB.\n")

    def roof_row(name, intensity, g):
        att = min(peak, intensity * bw)
        region = "compute-bound" if intensity >= ridge else "memory-bound"
        return [name, f"{intensity:.3f}", region, f"{att:.4f}", f"{g:.4f}", f"{g / att * 100:.1f}%"]

    text += "\n### Roofline mapping\n\n"
    text += (f"P_sustained = {peak:.4f} GFLOP/s, BW = {bw:.2f} GB/s, ridge I* = {ridge:.5f} FLOP/B. "
             "Attainable = min(P_sustained, I x BW).\n\n")
    text += L.md_table(["Kernel", "I (FLOP/B)", "Region", "Attainable GFLOP/s", "Achieved GFLOP/s",
                        "% of attainable"], [
        roof_row("V1 naive", 0.125, gf(st1)),
        roof_row("V2 i-k-j (I ~ 0.25: one 8-B B load per 2 FLOPs)", 0.25, gf(st2)),
        roof_row(f"V3 BS*={best_bs}", best_bs / 12, gf(best_st)),
    ])
    text += ("\n\n**Analysis (edit in your own words):** all three kernels sit far to the right of the "
             "ridge point, so they are compute-bound: the limit is how fast the Python interpreter runs "
             "each loop step, not the memory bus. V2 beats V1 because it hoists a_ik, removes index "
             "maths from the inner loop and reads B along rows (stride 1). Small tiles (BS = 4, 8) lose "
             "because loop overhead is paid more often; large tiles approach V2. Compare BS* footprint "
             "with your L1d/L2 sizes in the table above.\n")

    tag = emit_verify_tag("PHASE3", L.student_id(), gf(st1), gf(best_st))
    text += f"\n```text\n{tag}\n```\n"
    L.save_json("phase3b", {"gflops_v1": gf(st1), "gflops_v2": gf(st2), "best_bs": best_bs,
                            "gflops_v3_best": gf(best_st), "tag": tag})
    L.write_section("phase3b", text)


if __name__ == "__main__":
    main()
