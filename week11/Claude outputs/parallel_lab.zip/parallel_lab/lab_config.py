# ------------------------------------------------------------------
#  EDIT THIS FILE ONCE BEFORE YOU START
# ------------------------------------------------------------------

# Your student ID. It is mixed into every VERIFY_HASH line.
STUDENT_ID = 123456

# Leave these as None to use the values detected automatically in Phase 0.
# Only type a number if Phase 0 printed a wrong or "unknown" value.
P_PHYS = None        # physical cores, e.g. 8
LINE_BYTES = None    # cache line size in bytes, e.g. 64 (Intel/AMD) or 128 (Apple M)
L1D_KB = None        # L1 data cache PER CORE in KB, e.g. 48
L2_KB = None         # L2 cache PER CORE (or per cluster on Apple) in KB, e.g. 1280
