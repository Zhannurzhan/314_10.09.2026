"""Small helpers shared by all lab scripts.

- reads your hardware info (Phase 0) and saves it so later phases can use it
- saves each phase's tables to results/ so make_report.py can build the report
- makes worker pools where every task runs in its own process
"""
import json
import multiprocessing as mp
import os
import platform
import re
import subprocess
import sys
from multiprocessing import shared_memory

LAB_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(LAB_DIR, "results")
QUICK = "--quick" in sys.argv   # small sizes, only to check that the code works


# ---------------------------------------------------------------- config
def student_id():
    from lab_config import STUDENT_ID
    try:
        return int(STUDENT_ID)
    except ValueError:
        return STUDENT_ID


# ---------------------------------------------------------------- results files
def save_json(name, data):
    os.makedirs(RESULTS_DIR, exist_ok=True)
    with open(os.path.join(RESULTS_DIR, name + ".json"), "w") as f:
        json.dump(data, f, indent=2)


def load_json(name):
    path = os.path.join(RESULTS_DIR, name + ".json")
    if not os.path.exists(path):
        sys.exit(f"Missing results/{name}.json. Run the earlier phase first.")
    with open(path) as f:
        return json.load(f)


def write_section(name, text):
    """Print a phase's markdown and save it for the report."""
    if QUICK:
        text = "> **QUICK TEST MODE: small sizes. Run again without --quick before submitting.**\n\n" + text
    os.makedirs(RESULTS_DIR, exist_ok=True)
    with open(os.path.join(RESULTS_DIR, name + ".md"), "w", encoding="utf-8") as f:
        f.write(text.rstrip() + "\n")
    print("\n" + text)


def md_table(headers, rows):
    lines = ["| " + " | ".join(headers) + " |",
             "|:---|" + "|".join("---:" for _ in headers[1:]) + "|"]
    for r in rows:
        lines.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(lines)


def fmt_size(n):
    if n is None:
        return "unknown"
    if n >= 1024 ** 2:
        return f"{n / 1024 ** 2:g} MB"
    if n >= 1024:
        return f"{n / 1024:g} KB"
    return f"{n} B"


def split(n, p):
    """Cut range(n) into p nearly equal (lo, hi) pieces."""
    return [(t * n // p, (t + 1) * n // p) for t in range(p)]


# ---------------------------------------------------------------- shared memory
def attach_shm(name):
    """Open an existing shared-memory block without the resource-tracker warnings."""
    try:
        return shared_memory.SharedMemory(name=name, track=False)   # Python 3.13+
    except TypeError:
        return shared_memory.SharedMemory(name=name)


# ---------------------------------------------------------------- pools
_BARRIER = None


def _pool_init(barrier, extra_init, extra_args):
    global _BARRIER
    _BARRIER = barrier
    if extra_init is not None:
        extra_init(*extra_args)


def make_pool(p, extra_init=None, extra_args=()):
    """A pool of p processes. Call sync() at the start of each task:
    then each of the p tasks is forced into a different process and they all start together."""
    barrier = mp.Barrier(p)
    return mp.Pool(processes=p, initializer=_pool_init,
                   initargs=(barrier, extra_init, extra_args))


def sync():
    _BARRIER.wait(timeout=900)


# ---------------------------------------------------------------- hardware
def _run(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception:
        return ""


def _int(text, default=None):
    try:
        return int(str(text).strip())
    except (TypeError, ValueError):
        return default


def _to_bytes(text):
    if not text:
        return None
    m = re.search(r"([\d.]+)\s*([KMG])?", str(text), re.I)
    if not m:
        return None
    unit = (m.group(2) or "").upper()
    return int(float(m.group(1)) * {"K": 1024, "M": 1024 ** 2, "G": 1024 ** 3}.get(unit, 1))


def _per_instance(text):
    """lscpu prints '192 KiB (4 instances)' = total; turn it into size per core."""
    total = _to_bytes(text)
    m = re.search(r"\((\d+)\s+instance", text or "")
    if total and m:
        return total // int(m.group(1))
    return total


def detect_hardware():
    sysname = platform.system()
    hw = {
        "cpu_model": platform.processor() or platform.machine(),
        "p_log": mp.cpu_count(),
        "p_phys": None,
        "p_perf_cores": None,      # Apple / hybrid CPUs: number of performance cores
        "line_bytes": None,
        "l1d_bytes": None,         # per core
        "l2_bytes": None,          # per core (Apple: per cluster)
        "l3_bytes": None,          # shared, total
        "python_os": f"Python {platform.python_version()} / {sysname} {platform.release()}",
        "raw_os_output": "",
    }

    if sysname == "Linux":
        raw = _run(["lscpu"])
        kv = {}
        keep = []
        for line in raw.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                kv[k.strip()] = v.strip()
            if re.search(r"Model name|Socket|Core|Thread|L1d|L2|L3", line):
                keep.append(line)
        hw["cpu_model"] = kv.get("Model name", hw["cpu_model"])
        sockets = _int(kv.get("Socket(s)"), 1) or 1
        cores = _int(kv.get("Core(s) per socket")) or _int(kv.get("Core(s) per cluster"))
        tpc = _int(kv.get("Thread(s) per core"))
        if cores:
            hw["p_phys"] = sockets * cores
        elif tpc:
            hw["p_phys"] = hw["p_log"] // tpc
        hw["l1d_bytes"] = _per_instance(kv.get("L1d cache") or kv.get("L1d"))
        hw["l2_bytes"] = _per_instance(kv.get("L2 cache") or kv.get("L2"))
        hw["l3_bytes"] = _to_bytes(kv.get("L3 cache") or kv.get("L3"))
        line = _run(["getconf", "LEVEL1_DCACHE_LINESIZE"])
        if not _int(line):
            try:
                with open("/sys/devices/system/cpu/cpu0/cache/index0/coherency_line_size") as f:
                    line = f.read().strip()
            except OSError:
                line = ""
        hw["line_bytes"] = _int(line)
        hw["raw_os_output"] = "$ lscpu | grep -E 'Model name|Socket|Core|Thread|L1d|L2|L3'\n" + \
            "\n".join(keep) + f"\n$ getconf LEVEL1_DCACHE_LINESIZE\n{line}"

    elif sysname == "Darwin":
        keys = ["machdep.cpu.brand_string", "hw.physicalcpu", "hw.logicalcpu", "hw.cachelinesize",
                "hw.l1dcachesize", "hw.l2cachesize", "hw.l3cachesize",
                "hw.perflevel0.physicalcpu", "hw.perflevel1.physicalcpu"]
        vals = {k: _run(["sysctl", "-n", k]) for k in keys}
        hw["cpu_model"] = vals["machdep.cpu.brand_string"] or hw["cpu_model"]
        hw["p_phys"] = _int(vals["hw.physicalcpu"])
        hw["line_bytes"] = _int(vals["hw.cachelinesize"])
        hw["l1d_bytes"] = _int(vals["hw.l1dcachesize"])
        hw["l2_bytes"] = _int(vals["hw.l2cachesize"])
        hw["l3_bytes"] = _int(vals["hw.l3cachesize"])
        perf = _int(vals["hw.perflevel0.physicalcpu"])
        eff = _int(vals["hw.perflevel1.physicalcpu"])
        if perf and eff:
            hw["p_perf_cores"] = perf
        hw["raw_os_output"] = "\n".join(f"$ sysctl -n {k}\n{v or '(not available)'}" for k, v in vals.items())

    elif sysname == "Windows":
        cmd = ("Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,"
               "NumberOfLogicalProcessors,L2CacheSize,L3CacheSize | ConvertTo-Json")
        out = _run(["powershell", "-NoProfile", "-Command", cmd])
        hw["raw_os_output"] = "PS> " + cmd + "\n" + out
        try:
            data = json.loads(out)
            if isinstance(data, list):
                cpus = data
            else:
                cpus = [data]
            hw["cpu_model"] = cpus[0]["Name"].strip()
            hw["p_phys"] = sum(int(c["NumberOfCores"]) for c in cpus)
            l2_total_kb = int(cpus[0]["L2CacheSize"] or 0)
            if l2_total_kb and hw["p_phys"]:
                hw["l2_bytes"] = l2_total_kb * 1024 // int(cpus[0]["NumberOfCores"])
            hw["l3_bytes"] = int(cpus[0]["L3CacheSize"] or 0) * 1024 or None
        except Exception:
            pass
        hw["line_bytes"] = 64   # every x86-64 CPU uses 64-byte lines

    # manual overrides from lab_config.py
    try:
        import lab_config as cfg
        if getattr(cfg, "P_PHYS", None):
            hw["p_phys"] = int(cfg.P_PHYS)
        if getattr(cfg, "LINE_BYTES", None):
            hw["line_bytes"] = int(cfg.LINE_BYTES)
        if getattr(cfg, "L1D_KB", None):
            hw["l1d_bytes"] = int(cfg.L1D_KB) * 1024
        if getattr(cfg, "L2_KB", None):
            hw["l2_bytes"] = int(cfg.L2_KB) * 1024
    except ImportError:
        pass

    if not hw["p_phys"]:
        hw["p_phys"] = hw["p_log"]
    return hw
