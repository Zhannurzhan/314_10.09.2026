"""Build lab_report_<YourID>.md from the results/ folder and the source files.

Run:  python make_report.py
"""
import os
import re

import labutil as L

SECTIONS = ["phase0", "phase1", "phase2", "phase3a", "phase3b", "phase4"]
SOURCES = ["harness.py", "labutil.py", "lab_config.py", "task0_cal.py", "task1_falsesharing.py",
           "task2_scaling.py", "task3a_roofline.py", "task3b_gemm.py", "task4_scheduling.py",
           "run_all.py", "make_report.py"]


def main():
    sid = L.student_id()
    parts, tags, missing = [], [], []
    for name in SECTIONS:
        path = os.path.join(L.RESULTS_DIR, name + ".md")
        if not os.path.exists(path):
            missing.append(name)
            continue
        with open(path, encoding="utf-8") as f:
            text = f.read()
        parts.append(text)
        tags += re.findall(r"VERIFY_HASH\[[^\]]+\]: [0-9A-F]{16} \(P_log=\d+\)", text)

    out = [f"# Parallel Computing Lab Report: Student {sid}\n"]
    out.append("## Verification hashes\n\n```text\n" + "\n".join(tags) + "\n```\n")
    if missing:
        out.append(f"> Missing phases: {', '.join(missing)}\n")
    out += parts
    out.append("## Appendix: Python 3 source code\n")
    for src in SOURCES:
        p = os.path.join(L.LAB_DIR, src)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                out.append(f"### {src}\n\n```python\n{f.read().rstrip()}\n```\n")

    name = f"lab_report_{sid}.md"
    with open(os.path.join(L.LAB_DIR, name), "w", encoding="utf-8") as f:
        f.write("\n".join(out))
    print(f"Wrote {name} with {len(tags)} verification hashes.")
    if missing:
        print("Missing:", ", ".join(missing))


if __name__ == "__main__":
    main()
