"""Phase 2 - strong scaling (Amdahl) vs weak scaling (Gustafson) for p = 1 ... P_log.

Run:  python task2_scaling.py
"""
import math
import statistics
import time

import labutil as L
from harness import emit_verify_tag, run_benchmark

N_STRONG = 160_000 if L.QUICK else 1_600_000   # fixed size for strong scaling
N0 = 25_000 if L.QUICK else 250_000            # elements per worker for weak scaling
SERIAL_SHARE = 0.05                            # Stage A covers the first 5% of elements
WARMUP, TIMED = 1, 5                           # raise to 3, 9 if you have spare time


def stage_a(n_serial):
    """Strictly serial prefix filter: 12 transcendental ops (6 sin + 6 sqrt) per element."""
    sin, sqrt = math.sin, math.sqrt
    acc = 0.0
    for i in range(n_serial):
        x = (i + 1) * 1e-5
        x = sqrt(sin(x) ** 2 + 1.0)
        x = sqrt(sin(x) ** 2 + 1.0)
        x = sqrt(sin(x) ** 2 + 1.0)
        x = sqrt(sin(x) ** 2 + 1.0)
        x = sqrt(sin(x) ** 2 + 1.0)
        x = sqrt(sin(x) ** 2 + 1.0)
        acc += x
    return acc


def stage_b(lo, hi):
    """Embarrassingly parallel kernel: 35 multiply-add + sin iterations per element, no shared writes."""
    sin = math.sin
    s = 0.0
    for i in range(lo, hi):
        x = i * 1e-6
        for _ in range(35):
            x = x * 0.999999 + 1e-3 * sin(x)
        s += x
    return s


def stage_b_task(lo, hi):
    L.sync()
    return stage_b(lo, hi)


def measure(pool, p, n):
    a_times = []

    def trial():
        t0 = time.perf_counter_ns()
        stage_a(int(SERIAL_SHARE * n))                    # serial, in the parent
        t1 = time.perf_counter_ns()
        pool.starmap(stage_b_task, L.split(n, p), chunksize=1)   # parallel
        a_times.append((t1 - t0) / 1e6)

    st = run_benchmark(trial, warmup_runs=WARMUP, timed_runs=TIMED)
    return st, statistics.median(a_times[WARMUP:])


def main():
    hw = L.load_json("hardware")
    p_phys, p_log = hw["p_phys"], hw["p_log"]
    strong, weak = {}, {}
    for p in range(1, p_log + 1):
        with L.make_pool(p) as pool:            # created OUTSIDE the timed region
            strong[p] = measure(pool, p, N_STRONG)
            weak[p] = measure(pool, p, p * N0)
        print(f"  p={p:<3} strong={strong[p][0].median_ms:9.1f} ms   weak={weak[p][0].median_ms:9.1f} ms",
              flush=True)

    t1 = strong[1][0].median_ms
    s = strong[1][1] / t1
    s_inf = 1 / s

    def amdahl(p):
        return 1 / (s + (1 - s) / p)

    # ---------------- strong table
    rows, sp_strong = [], {}
    for p in range(1, p_log + 1):
        st, _ = strong[p]
        sp = t1 / st.median_ms
        sp_strong[p] = sp
        d = "-" if p == 1 else f"{sp - sp_strong[p - 1]:+.3f}"
        rows.append([p, f"{st.median_ms:.1f}", f"{st.iqr_ms:.1f}", f"{sp:.3f}",
                     f"{sp / p:.3f}", f"{amdahl(p):.3f}", d])
    text = (f"## 3. Phase 2: Strong vs Weak Scaling\n\nP_phys = {p_phys}, P_log = {p_log}. "
            f"Runs: {WARMUP} warm-up + {TIMED} timed per point.\n\n")
    text += f"### Experiment 2A: Strong scaling (N = {N_STRONG:,})\n\n"
    text += L.md_table(["p", "T_strong (ms)", "IQR (ms)", "S_strong", "E_strong",
                        "Amdahl prediction", "Marginal dS"], rows)

    # ---------------- weak table
    w1 = weak[1][0].median_ms
    rows, sg = [], {}
    for p in range(1, p_log + 1):
        st, ta = weak[p]
        alpha = ta / st.median_ms
        sg[p] = p - alpha * (p - 1)
        rows.append([p, f"{p * N0:,}", f"{st.median_ms:.1f}", f"{ta:.1f}", f"{alpha:.4f}",
                     f"{w1 / st.median_ms:.3f}", f"{sg[p]:.3f}"])
    text += f"\n\n### Experiment 2B: Weak scaling (N(p) = p x {N0:,})\n\n"
    text += L.md_table(["p", "N(p)", "T_weak (ms)", "T_StageA (ms)", "alpha",
                        "E_weak = T1/Tp", "S_Gustafson"], rows)

    # ---------------- Amdahl comparison
    text += "\n\n### Amdahl ceiling\n\n"
    text += L.md_table(["Quantity", "Value"], [
        ["Serial fraction s = T_StageA(1) / T_strong(1)", f"{s:.5f} ({s * 100:.2f}%)"],
        ["Amdahl max speedup S_inf = 1/s", f"{s_inf:.2f}"],
        [f"Amdahl prediction at p = P_log = {p_log}", f"{amdahl(p_log):.3f}"],
        [f"Observed S_strong at p = {p_log}", f"{sp_strong[p_log]:.3f}"],
        ["Observed / predicted", f"{sp_strong[p_log] / amdahl(p_log) * 100:.1f}%"],
    ])
    text += ("\n\n*Why observed can differ from Amdahl:* the formula only counts Stage A as serial. "
             "Real runs also pay for sending tasks to the pool, collecting results, OS scheduling, "
             "shared caches/memory bandwidth and (above P_phys) two threads sharing one core.\n")

    # ---------------- SMT / hybrid boundary
    boundary = hw["p_perf_cores"] if hw.get("p_perf_cores") else p_phys
    kind = "performance-core -> efficiency-core" if hw.get("p_perf_cores") else "physical -> SMT (Hyper-Threading)"
    text += f"\n### Inflection at p = {boundary} -> {boundary + 1} ({kind})\n\n"
    if p_log > boundary and boundary >= 2:
        before = [sp_strong[p] - sp_strong[p - 1] for p in range(2, boundary + 1)]
        after = [sp_strong[p] - sp_strong[p - 1] for p in range(boundary + 1, p_log + 1)]
        b, a = statistics.mean(before), statistics.mean(after)
        drop = (1 - a / b) * 100 if b else float("nan")
        step = sp_strong[boundary + 1] - sp_strong[boundary]
        text += L.md_table(["Quantity", "Value"], [
            [f"Mean marginal speedup per worker, p = 2..{boundary}", f"{b:.3f}"],
            [f"Mean marginal speedup per worker, p = {boundary + 1}..{p_log}", f"{a:.3f}"],
            [f"Marginal speedup of the single step {boundary} -> {boundary + 1}", f"{step:.3f}"],
            ["Drop in marginal speedup per added worker", f"{drop:.1f}%"],
        ])
        text += ("\n\nBelow the boundary every new worker gets its own core. Above it, the new worker "
                 "shares a core (SMT) or lands on a slower core (hybrid), so each extra worker adds "
                 "much less speedup.\n")
    else:
        text += ("Your CPU has no SMT or hybrid boundary inside p = 1..P_log "
                 "(P_log = P_phys and no slower core cluster), so there is no inflection to measure. "
                 "Say this in the report.\n")

    text += ("\n*Weak-scaling note:* Stage A covers 5% of N(p), so the serial work grows with p. "
             "That is why alpha and T_weak rise with p, and E_weak falls below 1. Gustafson's law "
             "assumes the serial time stays constant.\n")

    tag = emit_verify_tag("PHASE2", L.student_id(), sp_strong[p_log], sg[p_log])
    text += f"\n```text\n{tag}\n```\n"
    L.save_json("phase2", {"s": s, "S_inf": s_inf, "S_strong_Plog": sp_strong[p_log],
                           "S_gustafson_Plog": sg[p_log], "tag": tag})
    L.write_section("phase2", text)


if __name__ == "__main__":
    main()
