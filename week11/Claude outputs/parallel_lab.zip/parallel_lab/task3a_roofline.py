"""Phase 3A - measure your laptop's two ceilings: memory bandwidth and Python FLOP rate.

Run:  python task3a_roofline.py
"""
from multiprocessing import shared_memory

import labutil as L
from harness import run_benchmark

BYTES = 9_600_000 if L.QUICK else 96_000_000          # 96 MB per buffer (bigger than L3)
FLOPS_PER_WORKER = 8_000_000 if L.QUICK else 80_000_000

_SHM = []


def bw_init(name_a, name_b):
    _SHM.append(L.attach_shm(name_a))
    _SHM.append(L.attach_shm(name_b))


def bw_copy(lo, hi):
    L.sync()
    _SHM[0].buf[lo:hi] = _SHM[1].buf[lo:hi]      # native memcpy: 1 read + 1 write per byte


def flops_task(n_flops):
    L.sync()
    a, b = 0.999999, 1e-6
    x0, x1, x2, x3 = 1.0, 1.1, 1.2, 1.3
    x4, x5, x6, x7 = 1.4, 1.5, 1.6, 1.7
    x8, x9, x10, x11 = 1.8, 1.9, 2.0, 2.1
    x12, x13, x14, x15 = 2.2, 2.3, 2.4, 2.5
    for _ in range(n_flops // 32):             # 16 lines x 2 FLOPs (multiply + add) = 32 per pass
        x0 = x0 * a + b
        x1 = x1 * a + b
        x2 = x2 * a + b
        x3 = x3 * a + b
        x4 = x4 * a + b
        x5 = x5 * a + b
        x6 = x6 * a + b
        x7 = x7 * a + b
        x8 = x8 * a + b
        x9 = x9 * a + b
        x10 = x10 * a + b
        x11 = x11 * a + b
        x12 = x12 * a + b
        x13 = x13 * a + b
        x14 = x14 * a + b
        x15 = x15 * a + b
    return x0 + x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8 + x9 + x10 + x11 + x12 + x13 + x14 + x15


def main():
    hw = L.load_json("hardware")
    p = hw["p_phys"]
    buf_a = shared_memory.SharedMemory(create=True, size=BYTES)
    buf_b = shared_memory.SharedMemory(create=True, size=BYTES)
    try:
        pattern = bytes(range(256))
        buf_b.buf[:BYTES] = (pattern * (BYTES // 256 + 1))[:BYTES]
        with L.make_pool(p, bw_init, (buf_a.name, buf_b.name)) as pool:
            ranges = L.split(BYTES, p)
            bw = run_benchmark(lambda: pool.starmap(bw_copy, ranges, chunksize=1),
                               warmup_runs=2, timed_runs=9)
            ok = (bytes(buf_a.buf[:4096]) == bytes(buf_b.buf[:4096])
                  and bytes(buf_a.buf[BYTES - 4096:BYTES]) == bytes(buf_b.buf[BYTES - 4096:BYTES]))
            print(f"  copy median = {bw.median_ms:.2f} ms (copy correct: {ok})", flush=True)
            fl = run_benchmark(lambda: pool.starmap(flops_task, [(FLOPS_PER_WORKER,)] * p, chunksize=1),
                               warmup_runs=1, timed_runs=3)
            print(f"  FLOP kernel median = {fl.median_ms:.1f} ms", flush=True)
    finally:
        for s in (buf_a, buf_b):
            s.close()
            s.unlink()

    bw_gbs = 2 * BYTES / (bw.median_ms / 1000) / 1e9
    peak = p * FLOPS_PER_WORKER / (fl.median_ms / 1000) / 1e9
    ridge = peak / bw_gbs
    L.save_json("phase3a", {"bw_gbs": bw_gbs, "peak_gflops": peak, "ridge": ridge})

    text = f"## 4. Phase 3: Roofline and GEMM\n\n### Part 3A: Machine ceilings (P_phys = {p} workers)\n\n"
    text += L.md_table(["Quantity", "Measurement", "Result"], [
        ["BW_sustained", f"copy {BYTES / 1e6:.0f} MB, median {bw.median_ms:.2f} ms (IQR {bw.iqr_ms:.2f})",
         f"**{bw_gbs:.2f} GB/s**"],
        ["P_sustained", f"{p} x {FLOPS_PER_WORKER:,} FLOPs, median {fl.median_ms:.1f} ms",
         f"**{peak:.4f} GFLOP/s**"],
        ["Ridge point I* = P / BW", "", f"**{ridge:.5f} FLOP/Byte**"],
    ])
    text += ("\n\nThe ridge point is tiny because the Python interpreter is slow at arithmetic but "
             "memcpy runs at full hardware speed. Any kernel with intensity above I* is compute-bound "
             "(limited by the interpreter), which is true for all GEMM variants below.\n")
    L.write_section("phase3a", text)


if __name__ == "__main__":
    main()
