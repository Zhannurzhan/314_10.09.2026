"""Phase 4 - skewed workload: static block vs cyclic vs dynamic chunk queue.

Run:  python task4_scheduling.py
"""
import math
import multiprocessing as mp
import statistics
import time

import labutil as L
from harness import emit_verify_tag, run_benchmark

N_ITEMS = 6_000 if L.QUICK else 12_000
CHUNKS = [1, 4, 16, 64, 256, 1024]
WARMUP, TIMED = 1, 3

_S = {}


def sched_init(counter, lock, times):
    _S["counter"], _S["lock"], _S["times"] = counter, lock, times


def work_item(i):
    """K(i) = 1 + floor((i/60)^2) heavy iterations. Item 11,999 does ~40,000x item 0."""
    sin, cos, sqrt = math.sin, math.cos, math.sqrt
    x = 0.5 + i * 1e-4
    acc = 0.0
    for _ in range(1 + (i * i) // 3600):
        x = sin(x) + 0.5 * cos(x) + 0.1
        acc += sqrt(x * x + 1.0)
    return acc


def sched_task(strategy, t, p, chunk, n):
    L.sync()
    t0 = time.perf_counter()
    acc = 0.0
    if strategy == "block":                      # Strategy 1: contiguous block
        for i in range(t * n // p, (t + 1) * n // p):
            acc += work_item(i)
    elif strategy == "cyclic":                   # Strategy 2: round-robin
        for i in range(t, n, p):
            acc += work_item(i)
    else:                                        # Strategy 3: shared counter, chunks of size C
        counter, lock = _S["counter"], _S["lock"]
        while True:
            with lock:
                start = counter.value
                counter.value = start + chunk
            if start >= n:
                break
            for i in range(start, min(start + chunk, n)):
                acc += work_item(i)
    _S["times"][t] = (time.perf_counter() - t0) * 1000.0      # this worker's active time (ms)
    return acc


def main():
    hw = L.load_json("hardware")
    p = hw["p_phys"]
    counter = mp.RawValue("i", 0)
    lock = mp.Lock()
    times = mp.RawArray("d", p)
    configs = [("Strategy 1: block static", "block", 0),
               ("Strategy 2: cyclic static", "cyclic", 0)] + \
              [("Strategy 3: dynamic", "dynamic", c) for c in CHUNKS]

    out = []
    with L.make_pool(p, sched_init, (counter, lock, times)) as pool:
        for label, strategy, chunk in configs:
            lambdas, workers, sums = [], [], []

            def trial(strategy=strategy, chunk=chunk, lambdas=lambdas, workers=workers, sums=sums):
                counter.value = 0
                for t in range(p):
                    times[t] = 0.0
                args = [(strategy, t, p, chunk, N_ITEMS) for t in range(p)]
                sums.append(sum(pool.starmap(sched_task, args, chunksize=1)))
                wt = list(times)
                lambdas.append(max(wt) / (sum(wt) / p))
                workers.append(wt)

            st = run_benchmark(trial, WARMUP, TIMED)
            lam = statistics.median(lambdas[WARMUP:])
            wt = workers[-1]
            out.append((label, chunk, st, lam, max(wt), min(wt), sums[-1]))
            print(f"  {label:<26} C={chunk or '-':<5} Twall={st.median_ms:9.1f} ms  lambda={lam:.3f}",
                  flush=True)

    t_block = out[0][2].median_ms
    rows = []
    for label, chunk, st, lam, wmax, wmin, _ in out:
        rows.append([label, chunk or "-", f"{st.median_ms:.1f}", f"{st.iqr_ms:.1f}", f"{lam:.3f}",
                     f"{wmax:.1f}", f"{wmin:.1f}", f"{t_block / st.median_ms:.2f}x"])
    dyn = [r for r in out if r[1]]
    best = min(dyn, key=lambda r: r[2].median_ms)
    c_star, t_star = best[1], best[2].median_ms
    same = all(abs(r[6] - out[0][6]) < 1e-6 * abs(out[0][6]) for r in out)

    text = (f"## 5. Phase 4: Scheduling and Load Imbalance\n\nN = {N_ITEMS:,} items, "
            f"K(i) = 1 + floor((i/60)^2), p = P_phys = {p}. Runs: {WARMUP} warm-up + {TIMED} timed.\n\n")
    text += L.md_table(["Strategy", "Chunk C", "T_wall (ms)", "IQR (ms)", "lambda",
                        "Slowest worker (ms)", "Fastest worker (ms)", "Speedup vs block"], rows)
    text += (f"\n\n- All strategies computed the same total: {'yes' if same else 'NO - check code'}\n"
             f"- Best chunk size **C* = {c_star}** (T_wall = {t_star:.1f} ms, "
             f"{t_block / t_star:.2f}x faster than block static).\n")
    text += ("\n**Trade-off (edit in your own words):** with C = 1 the work is spread almost perfectly "
             "(lambda close to 1), but every single item needs the lock and a write to the shared counter, "
             "whose cache line bounces between cores. With C = 1024 the lock is taken only ~12 times, "
             "but the last chunks hold the heaviest items, so some workers finish early and wait "
             "(lambda grows). C* is the middle point where both costs are small. Block static is the "
             "worst because the last worker gets the heaviest block of items.\n")

    tag = emit_verify_tag("PHASE4", L.student_id(), t_block, t_star)
    text += f"\n```text\n{tag}\n```\n"
    L.save_json("phase4", {"t_block": t_block, "c_star": c_star, "t_star": t_star, "tag": tag})
    L.write_section("phase4", text)


if __name__ == "__main__":
    main()
