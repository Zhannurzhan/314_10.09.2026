# parallel_lab: how to run

1. Open `lab_config.py` and put your student ID in `STUDENT_ID`.
2. Open a terminal in this folder.
3. Test that everything works (about 1-3 minutes, small sizes):

   ```
   python run_all.py --quick
   ```

4. Run the real lab (about 15-40 minutes, depends on your laptop):

   ```
   python run_all.py
   ```

   Or run one phase at a time, in this order:

   ```
   python task0_cal.py
   python task1_falsesharing.py
   python task2_scaling.py
   python task3a_roofline.py
   python task3b_gemm.py
   python task4_scheduling.py
   python make_report.py
   ```

5. Open `lab_report_<YourID>.md`. Rewrite every paragraph marked **(edit in your own words)**.

Notes

- On Windows use `py` instead of `python` if `python` does not work.
- Close other heavy programs (browser, games) and plug in the charger while it runs.
- If Phase 0 says a cache size or core count is "unknown", type the right value into `lab_config.py`, then run `task0_cal.py` again.
- `results/` holds each phase's tables. If one phase fails, fix it and run only that phase, then `make_report.py`.
