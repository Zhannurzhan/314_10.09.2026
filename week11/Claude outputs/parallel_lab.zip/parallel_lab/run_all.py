"""Run every phase in order, then build the report.

    python run_all.py            full lab (use this for your submission)
    python run_all.py --quick    small sizes, only to test that everything works (~3 min)
"""
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = ["task0_cal.py", "task1_falsesharing.py", "task2_scaling.py",
           "task3a_roofline.py", "task3b_gemm.py", "task4_scheduling.py", "make_report.py"]

if __name__ == "__main__":
    extra = [a for a in sys.argv[1:] if a == "--quick"]
    start = time.time()
    for script in SCRIPTS:
        print(f"\n===== {script} ({(time.time() - start) / 60:.1f} min elapsed) =====", flush=True)
        r = subprocess.run([sys.executable, script] + extra, cwd=HERE)
        if r.returncode != 0:
            sys.exit(f"{script} failed (exit code {r.returncode}). Fix it and run that script again.")
    print(f"\nAll done in {(time.time() - start) / 60:.1f} minutes.")
